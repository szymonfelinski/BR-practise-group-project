define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SettingIds = /** @class */ (function () {
        function SettingIds() {
        }
        SettingIds.SerieId = "serieId";
        SettingIds.ExpandState = "expandState";
        SettingIds.CursorInfo = "cursorInfo";
        return SettingIds;
    }());
    exports.SettingIds = SettingIds;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0dGluZ0lkcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvd2lkZ2V0cy9jdXJzb3JJbmZvV2lkZ2V0L21vZGVsL3NldHRpbmdJZHMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0lBQUE7UUFBQTtRQUlBLENBQUM7UUFIVSxrQkFBTyxHQUFHLFNBQVMsQ0FBQztRQUNwQixzQkFBVyxHQUFHLGFBQWEsQ0FBQztRQUM1QixxQkFBVSxHQUFHLFlBQVksQ0FBQTtRQUNwQyxpQkFBQztLQUFBLEFBSkQsSUFJQztJQUpZLGdDQUFVIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIFNldHRpbmdJZHN7XHJcbiAgICBzdGF0aWMgU2VyaWVJZCA9IFwic2VyaWVJZFwiO1xyXG4gICAgc3RhdGljIEV4cGFuZFN0YXRlID0gXCJleHBhbmRTdGF0ZVwiO1xyXG4gICAgc3RhdGljIEN1cnNvckluZm8gPSBcImN1cnNvckluZm9cIlxyXG59Il19