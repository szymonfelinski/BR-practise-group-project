define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SettingIds = /** @class */ (function () {
        function SettingIds() {
        }
        SettingIds.Name = "name";
        SettingIds.RawPointsX = "rawPointsX";
        SettingIds.RawPointsY = "rawPointsY";
        return SettingIds;
    }());
    exports.SettingIds = SettingIds;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0dGluZ0lkcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvbW9kZWxzL2NvbW1vbi9zaWduYWwvc2V0dGluZ0lkcy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7SUFBQTtRQUFBO1FBSUEsQ0FBQztRQUhVLGVBQUksR0FBRyxNQUFNLENBQUM7UUFDZCxxQkFBVSxHQUFHLFlBQVksQ0FBQztRQUMxQixxQkFBVSxHQUFHLFlBQVksQ0FBQztRQUNyQyxpQkFBQztLQUFBLEFBSkQsSUFJQztJQUpZLGdDQUFVIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIFNldHRpbmdJZHN7XHJcbiAgICBzdGF0aWMgTmFtZSA9IFwibmFtZVwiO1xyXG4gICAgc3RhdGljIFJhd1BvaW50c1ggPSBcInJhd1BvaW50c1hcIjtcclxuICAgIHN0YXRpYyBSYXdQb2ludHNZID0gXCJyYXdQb2ludHNZXCI7XHJcbn0iXX0=