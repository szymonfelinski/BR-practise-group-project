define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var CursorInfoVisibility = /** @class */ (function () {
        function CursorInfoVisibility(id, visible) {
            this.id = id;
            this.visible = visible;
        }
        return CursorInfoVisibility;
    }());
    exports.CursorInfoVisibility = CursorInfoVisibility;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3Vyc29ySW5mb1Zpc2liaWxpdHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBwL3dpZGdldHMvY3Vyc29ySW5mb1dpZGdldC9tb2RlbC9jdXJzb3JJbmZvVmlzaWJpbGl0eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7SUFBQTtRQUlJLDhCQUFZLEVBQVUsRUFBRSxPQUFlO1lBQ25DLElBQUksQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7UUFDM0IsQ0FBQztRQUNMLDJCQUFDO0lBQUQsQ0FBQyxBQVJELElBUUM7SUFSWSxvREFBb0IiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY2xhc3MgQ3Vyc29ySW5mb1Zpc2liaWxpdHl7XHJcbiAgICByZWFkb25seSBpZDogc3RyaW5nO1xyXG4gICAgcmVhZG9ubHkgdmlzaWJsZTogc3RyaW5nO1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKGlkOiBzdHJpbmcsIHZpc2libGU6IHN0cmluZykge1xyXG4gICAgICAgIHRoaXMuaWQgPSBpZDtcclxuICAgICAgICB0aGlzLnZpc2libGUgPSB2aXNpYmxlO1xyXG4gICAgfVxyXG59Il19