define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    /**
     * implements the base class for states
     *
     * @export
     * @class State
     */
    var State = /** @class */ (function () {
        function State() {
        }
        return State;
    }());
    exports.State = State;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvYXBwL2ZyYW1ld29yay9zdGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7SUFDQTs7Ozs7T0FLRztJQUNIO1FBQUE7UUFFQSxDQUFDO1FBQUQsWUFBQztJQUFELENBQUMsQUFGRCxJQUVDO0lBRlksc0JBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuLyoqXHJcbiAqIGltcGxlbWVudHMgdGhlIGJhc2UgY2xhc3MgZm9yIHN0YXRlc1xyXG4gKlxyXG4gKiBAZXhwb3J0XHJcbiAqIEBjbGFzcyBTdGF0ZVxyXG4gKi9cclxuZXhwb3J0IGNsYXNzIFN0YXRle1xyXG5cclxufVxyXG5cclxuZXhwb3J0IHR5cGUgVFN0YXRlQ29uc3RydWN0b3IgPSBuZXcgKCkgPT4gU3RhdGU7Il19