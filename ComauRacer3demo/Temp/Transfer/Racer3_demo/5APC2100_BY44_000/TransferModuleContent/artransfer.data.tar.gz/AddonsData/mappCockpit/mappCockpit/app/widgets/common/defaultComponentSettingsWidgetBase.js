define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var DefaultComponentSettingsWidgetBase = /** @class */ (function () {
        function DefaultComponentSettingsWidgetBase() {
        }
        DefaultComponentSettingsWidgetBase.ImageProviderId = "ImageProvider";
        DefaultComponentSettingsWidgetBase.CommonLayoutProviderId = "CommonLayoutProvider";
        return DefaultComponentSettingsWidgetBase;
    }());
    exports.DefaultComponentSettingsWidgetBase = DefaultComponentSettingsWidgetBase;
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmYXVsdENvbXBvbmVudFNldHRpbmdzV2lkZ2V0QmFzZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9hcHAvd2lkZ2V0cy9jb21tb24vZGVmYXVsdENvbXBvbmVudFNldHRpbmdzV2lkZ2V0QmFzZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7SUFBQTtRQUFBO1FBR0EsQ0FBQztRQUZpQixrREFBZSxHQUFHLGVBQWUsQ0FBQztRQUNsQyx5REFBc0IsR0FBRyxzQkFBc0IsQ0FBQztRQUNsRSx5Q0FBQztLQUFBLEFBSEQsSUFHQztJQUhZLGdGQUFrQyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBEZWZhdWx0Q29tcG9uZW50U2V0dGluZ3NXaWRnZXRCYXNle1xyXG4gICAgcHVibGljIHN0YXRpYyBJbWFnZVByb3ZpZGVySWQgPSBcIkltYWdlUHJvdmlkZXJcIjtcclxuICAgIHB1YmxpYyBzdGF0aWMgQ29tbW9uTGF5b3V0UHJvdmlkZXJJZCA9IFwiQ29tbW9uTGF5b3V0UHJvdmlkZXJcIjtcclxufSJdfQ==